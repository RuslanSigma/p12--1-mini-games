using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ігри.Pages
{
    public class game1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
