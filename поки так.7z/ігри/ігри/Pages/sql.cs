﻿using System;
using System.Data.SqlClient;

namespace ігри.Pages
{
    public class sql
    {

    }
}
