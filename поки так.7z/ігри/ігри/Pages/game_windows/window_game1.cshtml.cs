using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ігри.Pages.game_windows
{
    public class window_game1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
