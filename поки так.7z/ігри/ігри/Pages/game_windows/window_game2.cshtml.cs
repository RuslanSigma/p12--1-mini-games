using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ігри.Pages.game_windows
{
    public class window_game2Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
