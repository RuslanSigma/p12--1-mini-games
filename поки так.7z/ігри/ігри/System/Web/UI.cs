﻿namespace System.Web
{
    public class UI
    {
        public class Page
        {
        }
    }
}