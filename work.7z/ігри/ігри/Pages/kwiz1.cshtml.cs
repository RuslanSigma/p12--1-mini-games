using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ігри.Pages
{
    public class kwiz1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
