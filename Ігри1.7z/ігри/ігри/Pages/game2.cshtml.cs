using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ігри.Pages
{
    public class HomeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
